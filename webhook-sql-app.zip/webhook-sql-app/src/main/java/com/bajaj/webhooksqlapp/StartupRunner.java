package com.bajaj.webhooksqlapp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Configuration
public class StartupRunner {

    @Bean
    CommandLineRunner executeOnStartup() {
        return args -> {

            RestTemplate restTemplate = new RestTemplate();

            String generateUrl =
                    "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            String body = """
            {
              "name": "John Doe",
              "regNo": "REG12347",
              "email": "john@example.com"
            }
            """;

            HttpEntity<String> request = new HttpEntity<>(body, headers);

            ResponseEntity<Map> response =
                    restTemplate.postForEntity(generateUrl, request, Map.class);

            String webhookUrl = (String) response.getBody().get("webhook");
            String accessToken = (String) response.getBody().get("accessToken");

            String finalQuery = """
            SELECT
                d.DEPARTMENT_NAME,
                e_salary.total_salary AS SALARY,
                CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME) AS EMPLOYEE_NAME,
                TIMESTAMPDIFF(YEAR, e.DOB, CURDATE()) AS AGE
            FROM (
                SELECT
                    e.EMP_ID,
                    e.DEPARTMENT,
                    SUM(p.AMOUNT) AS total_salary
                FROM EMPLOYEE e
                JOIN PAYMENTS p ON e.EMP_ID = p.EMP_ID
                WHERE DAY(p.PAYMENT_TIME) <> 1
                GROUP BY e.EMP_ID, e.DEPARTMENT
            ) e_salary
            JOIN EMPLOYEE e ON e_salary.EMP_ID = e.EMP_ID
            JOIN DEPARTMENT d ON e_salary.DEPARTMENT = d.DEPARTMENT_ID
            WHERE e_salary.total_salary = (
                SELECT MAX(es2.total_salary)
                FROM (
                    SELECT
                        e2.EMP_ID,
                        e2.DEPARTMENT,
                        SUM(p2.AMOUNT) AS total_salary
                    FROM EMPLOYEE e2
                    JOIN PAYMENTS p2 ON e2.EMP_ID = p2.EMP_ID
                    WHERE DAY(p2.PAYMENT_TIME) <> 1
                    GROUP BY e2.EMP_ID, e2.DEPARTMENT
                ) es2
                WHERE es2.DEPARTMENT = e_salary.DEPARTMENT
            );
            """;

            HttpHeaders submitHeaders = new HttpHeaders();
            submitHeaders.setContentType(MediaType.APPLICATION_JSON);
            submitHeaders.set("Authorization", accessToken);

            String submitBody = """
            {
              "finalQuery": "%s"
            }
            """.formatted(finalQuery.replace("\n", " "));

            HttpEntity<String> submitRequest =
                    new HttpEntity<>(submitBody, submitHeaders);

            restTemplate.postForEntity(webhookUrl, submitRequest, String.class);
        };
    }
}
