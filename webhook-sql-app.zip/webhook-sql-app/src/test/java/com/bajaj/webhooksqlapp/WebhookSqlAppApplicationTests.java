package com.bajaj.webhooksqlapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebhookSqlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
